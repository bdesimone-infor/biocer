<?php

/**
 *  Compability with the old PHP Toolkit
 */

define('ONELOGIN_SAML_DIR', 'lib/Saml/');
require_once ONELOGIN_SAML_DIR . 'AuthRequest.php';
require_once ONELOGIN_SAML_DIR . 'Response.php';
require_once ONELOGIN_SAML_DIR . 'Settings.php';
require_once ONELOGIN_SAML_DIR . 'XmlSec.php';
require_once ONELOGIN_SAML_DIR . 'Metadata.php';
