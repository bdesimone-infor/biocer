<?php

global $sugar_config, $db;

$sugar_config['default_max_tabs'] = 10;
$sugar_config['suitecrm_version'] = '7.10.24';

if (!isset($sugar_config['email_enable_auto_send_opt_in'])) {
    $sugar_config['email_enable_auto_send_opt_in'] = true;
}
if (!isset($sugar_config['email_enable_confirm_opt_in'])) {
    $sugar_config['email_enable_confirm_opt_in'] = 'not-opt-in';
}
if (!isset($sugar_config['imap_test'])) {
    $sugar_config['imap_test'] = false;
}
if (!isset($sugar_config['strict_id_validation'])) {
    $sugar_config['strict_id_validation'] = false;
}

if (isset($sugar_config['default_number_grouping_separator'])) {
    if (!isset($sugar_config['default_number_grouping_seperator'])) {
        $sugar_config['default_number_grouping_seperator'] = $sugar_config['default_number_grouping_separator'];
    }
    unset($sugar_config['default_number_grouping_separator']);
}

if (isset($sugar_config['default_decimal_separator'])) {
    if (!isset($sugar_config['default_decimal_seperator'])) {
        $sugar_config['default_decimal_seperator'] = $sugar_config['default_decimal_separator'];
    }
    unset($sugar_config['default_decimal_separator']);
}

ksort($sugar_config);
write_array_to_file('sugar_config', $sugar_config, 'config.php');

